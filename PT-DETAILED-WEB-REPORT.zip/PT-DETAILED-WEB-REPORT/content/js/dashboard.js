/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 99.81538461538462, "KoPercent": 0.18461538461538463};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.9270833333333334, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.9996, 500, 1500, "https://hls.demoblaze.com/about_demo_hls_600k00000.ts"], "isController": false}, {"data": [0.336, 500, 1500, "Enter credentials and click on Log in"], "isController": true}, {"data": [0.962, 500, 1500, "https://api.demoblaze.com/bycat"], "isController": false}, {"data": [1.0, 500, 1500, "https://hls.demoblaze.com/index.m3u8"], "isController": false}, {"data": [1.0, 500, 1500, "https://hls.demoblaze.com/about_demo_hls_600k.m3u8"], "isController": false}, {"data": [0.624, 500, 1500, "Click on Log out"], "isController": true}, {"data": [0.948, 500, 1500, "Click on Add to cart"], "isController": true}, {"data": [0.766, 500, 1500, "https://www.demoblaze.com/index.html-11"], "isController": false}, {"data": [0.986, 500, 1500, "https://www.demoblaze.com/index.html-10"], "isController": false}, {"data": [0.988, 500, 1500, "https://www.demoblaze.com/index.html-13"], "isController": false}, {"data": [0.966, 500, 1500, "https://api.demoblaze.com/check"], "isController": false}, {"data": [0.978, 500, 1500, "https://www.demoblaze.com/index.html-12"], "isController": false}, {"data": [0.994, 500, 1500, "https://www.demoblaze.com/index.html-15"], "isController": false}, {"data": [1.0, 500, 1500, "https://www.demoblaze.com/index.html-14"], "isController": false}, {"data": [0.994, 500, 1500, "https://www.demoblaze.com/prod.html?idp_=10-11"], "isController": false}, {"data": [0.994, 500, 1500, "https://www.demoblaze.com/prod.html?idp_=10-10"], "isController": false}, {"data": [0.962, 500, 1500, "Click on Monitors"], "isController": true}, {"data": [0.982, 500, 1500, "https://www.demoblaze.com/prod.html?idp_=10-12"], "isController": false}, {"data": [0.998, 500, 1500, "https://www.demoblaze.com/index.html-4"], "isController": false}, {"data": [0.658, 500, 1500, "https://www.demoblaze.com/prod.html?idp_=10"], "isController": false}, {"data": [0.996, 500, 1500, "https://www.demoblaze.com/index.html-3"], "isController": false}, {"data": [0.923, 500, 1500, "https://api.demoblaze.com/entries"], "isController": false}, {"data": [0.996, 500, 1500, "https://www.demoblaze.com/index.html-6"], "isController": false}, {"data": [0.9984, 500, 1500, "https://www.demoblaze.com/config.json"], "isController": false}, {"data": [0.8675, 500, 1500, "https://www.demoblaze.com/index.html"], "isController": false}, {"data": [1.0, 500, 1500, "https://www.demoblaze.com/index.html-5"], "isController": false}, {"data": [0.99, 500, 1500, "https://www.demoblaze.com/index.html-8"], "isController": false}, {"data": [0.968, 500, 1500, "https://api.demoblaze.com/view"], "isController": false}, {"data": [0.982, 500, 1500, "https://www.demoblaze.com/index.html-7"], "isController": false}, {"data": [0.988, 500, 1500, "https://www.demoblaze.com/index.html-9"], "isController": false}, {"data": [0.998, 500, 1500, "https://www.demoblaze.com/prod.html?idp_=10-2"], "isController": false}, {"data": [0.948, 500, 1500, "https://api.demoblaze.com/addtocart"], "isController": false}, {"data": [1.0, 500, 1500, "https://www.demoblaze.com/prod.html?idp_=10-1"], "isController": false}, {"data": [0.996, 500, 1500, "https://www.demoblaze.com/prod.html?idp_=10-0"], "isController": false}, {"data": [0.996, 500, 1500, "https://www.demoblaze.com/index.html-0"], "isController": false}, {"data": [0.99, 500, 1500, "https://www.demoblaze.com/index.html-2"], "isController": false}, {"data": [0.49, 500, 1500, "Click on Home"], "isController": true}, {"data": [0.996, 500, 1500, "https://www.demoblaze.com/index.html-1"], "isController": false}, {"data": [0.006, 500, 1500, "Load Website URL"], "isController": true}, {"data": [0.992, 500, 1500, "https://www.demoblaze.com/prod.html?idp_=10-9"], "isController": false}, {"data": [0.984, 500, 1500, "https://www.demoblaze.com/prod.html?idp_=10-8"], "isController": false}, {"data": [0.268, 500, 1500, "Click on first result"], "isController": true}, {"data": [0.998, 500, 1500, "https://www.demoblaze.com/prod.html?idp_=10-7"], "isController": false}, {"data": [0.998, 500, 1500, "https://www.demoblaze.com/prod.html?idp_=10-6"], "isController": false}, {"data": [0.998, 500, 1500, "https://www.demoblaze.com/prod.html?idp_=10-5"], "isController": false}, {"data": [1.0, 500, 1500, "https://www.demoblaze.com/prod.html?idp_=10-4"], "isController": false}, {"data": [0.956, 500, 1500, "https://api.demoblaze.com/login"], "isController": false}, {"data": [0.996, 500, 1500, "https://www.demoblaze.com/prod.html?idp_=10-3"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 16250, 30, 0.18461538461538463, 199.36424615384604, 5, 1943, 152.0, 429.0, 511.0, 946.9799999999996, 163.3576275446092, 5716.481164787007, 114.22407090349334], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["https://hls.demoblaze.com/about_demo_hls_600k00000.ts", 1250, 0, 0.0, 78.50239999999998, 15, 511, 40.0, 248.0, 303.45000000000005, 408.47, 12.860611547800321, 1366.5128202613791, 5.360262703712087], "isController": false}, {"data": ["Enter credentials and click on Log in", 250, 0, 0.0, 1394.456, 1041, 2438, 1372.5, 1698.0, 1817.9, 2095.6200000000013, 4.14621202069789, 18.702234341830305, 14.868057167971342], "isController": true}, {"data": ["https://api.demoblaze.com/bycat", 250, 0, 0.0, 372.6199999999999, 272, 1108, 340.0, 484.0, 523.8, 808.0600000000036, 4.211093705257129, 3.1501612848889113, 1.7436559873330302], "isController": false}, {"data": ["https://hls.demoblaze.com/index.m3u8", 1250, 0, 0.0, 52.657599999999974, 15, 314, 38.0, 120.90000000000009, 152.0, 193.49, 12.854131317805543, 5.871064225667129, 5.1446652141498275], "isController": false}, {"data": ["https://hls.demoblaze.com/about_demo_hls_600k.m3u8", 1250, 0, 0.0, 35.048, 15, 272, 35.0, 52.90000000000009, 62.0, 81.0, 12.86259659810045, 17.93427824111709, 5.323406678002902], "isController": false}, {"data": ["Click on Log out", 250, 0, 0.0, 628.8679999999997, 432, 2112, 586.0, 821.0, 896.8, 1074.43, 4.320699607680475, 17.151455913741554, 11.07685606453397], "isController": true}, {"data": ["Click on Add to cart", 250, 0, 0.0, 376.8839999999998, 281, 911, 347.5, 503.0, 539.8, 624.6200000000003, 4.307448439842175, 0.8288136533193198, 2.178963175623288], "isController": true}, {"data": ["https://www.demoblaze.com/index.html-11", 250, 2, 0.8, 420.2039999999999, 124, 1239, 457.0, 605.9, 663.45, 778.0900000000004, 4.222616333079976, 1418.4496829079048, 2.249862764969175], "isController": false}, {"data": ["https://www.demoblaze.com/index.html-10", 250, 1, 0.4, 271.5399999999998, 69, 867, 225.0, 444.0, 468.45, 690.3500000000029, 4.226685602218164, 189.2811352190691, 2.257000580112599], "isController": false}, {"data": ["https://www.demoblaze.com/index.html-13", 250, 0, 0.0, 166.07200000000003, 53, 1229, 119.0, 339.60000000000025, 389.9, 1023.9900000000032, 4.235924024466697, 65.4267091159203, 2.283427794439079], "isController": false}, {"data": ["https://api.demoblaze.com/check", 750, 0, 0.0, 361.7200000000005, 266, 1103, 329.0, 489.0, 515.4499999999999, 772.6300000000008, 8.628624022089278, 2.5617575788080993, 3.732891056431201], "isController": false}, {"data": ["https://www.demoblaze.com/index.html-12", 250, 1, 0.4, 258.756, 42, 1251, 257.0, 439.9, 492.1499999999999, 627.7000000000003, 4.228973543541512, 650.8676565195971, 2.3651690902209217], "isController": false}, {"data": ["https://www.demoblaze.com/index.html-15", 250, 0, 0.0, 187.29600000000008, 51, 1250, 153.5, 343.00000000000006, 378.0, 1023.2900000000029, 4.233341800016934, 39.602184933536535, 2.1580121285242573], "isController": false}, {"data": ["https://www.demoblaze.com/index.html-14", 250, 0, 0.0, 140.89600000000002, 52, 424, 97.0, 277.9, 310.44999999999976, 413.43000000000006, 4.231550440081246, 134.75929420383378, 2.3058643999661474], "isController": false}, {"data": ["https://www.demoblaze.com/prod.html?idp_=10-11", 250, 1, 0.4, 168.55600000000013, 49, 1032, 155.0, 274.9, 377.5999999999999, 436.01000000000045, 4.275550690928991, 0.7276619845823642, 2.4244877623050347], "isController": false}, {"data": ["https://www.demoblaze.com/prod.html?idp_=10-10", 250, 1, 0.4, 194.58400000000003, 49, 550, 167.5, 351.40000000000003, 391.69999999999993, 469.5400000000004, 4.2762820293524, 0.7632996380127262, 2.399946359387294], "isController": false}, {"data": ["Click on Monitors", 250, 0, 0.0, 372.6199999999999, 272, 1108, 340.0, 484.0, 523.8, 808.0600000000036, 4.211164639692753, 3.1502143482801603, 1.7436853586227807], "isController": true}, {"data": ["https://www.demoblaze.com/prod.html?idp_=10-12", 250, 3, 1.2, 164.804, 52, 830, 150.0, 293.0, 365.34999999999997, 562.98, 4.286032676713127, 31.916059523350306, 2.1545183088600868], "isController": false}, {"data": ["https://www.demoblaze.com/index.html-4", 250, 0, 0.0, 190.58000000000004, 50, 716, 163.5, 374.9, 394.45, 438.45000000000005, 4.2154250834654166, 15.859071357661957, 2.1735785586618555], "isController": false}, {"data": ["https://www.demoblaze.com/prod.html?idp_=10", 250, 5, 2.0, 585.9839999999995, 278, 1607, 538.5, 787.7, 1026.7999999999997, 1417.0800000000008, 4.232481758003623, 140.3489132309496, 30.148612354402626], "isController": false}, {"data": ["https://www.demoblaze.com/index.html-3", 250, 0, 0.0, 217.80400000000006, 63, 672, 196.5, 387.9, 426.24999999999994, 526.3800000000006, 4.223757792833128, 117.07644486834548, 2.285118962138235], "isController": false}, {"data": ["https://api.demoblaze.com/entries", 1000, 0, 0.0, 398.48799999999966, 271, 1356, 381.0, 536.6999999999999, 571.0, 748.7400000000002, 10.243697565073088, 29.320743615615495, 3.5612854816074413], "isController": false}, {"data": ["https://www.demoblaze.com/index.html-6", 250, 0, 0.0, 211.09599999999998, 55, 747, 170.0, 372.9, 397.0, 488.0300000000004, 4.21556724672872, 17.549933394037502, 2.1283674478112773], "isController": false}, {"data": ["https://www.demoblaze.com/config.json", 1250, 0, 0.0, 80.51759999999985, 47, 877, 57.0, 99.0, 263.0, 292.94000000000005, 12.83552050602756, 2.9605027769648617, 5.728352413334566], "isController": false}, {"data": ["https://www.demoblaze.com/index.html", 1000, 5, 0.5, 309.27000000000027, 49, 1943, 63.0, 973.9, 1094.85, 1479.2600000000007, 10.098052085752657, 2086.4185577898897, 25.192292945753266], "isController": false}, {"data": ["https://www.demoblaze.com/index.html-5", 250, 0, 0.0, 184.432, 50, 423, 161.0, 353.8, 376.45, 422.49, 4.215993794057136, 4.957646389844514, 2.1738718000607102], "isController": false}, {"data": ["https://www.demoblaze.com/index.html-8", 250, 1, 0.4, 266.8200000000002, 99, 749, 215.5, 440.9, 456.0, 578.9900000000014, 4.225613981711542, 140.3824233473624, 2.1413463915369406], "isController": false}, {"data": ["https://api.demoblaze.com/view", 250, 0, 0.0, 366.9439999999999, 265, 1154, 330.5, 480.70000000000005, 521.3499999999999, 1011.4000000000005, 4.304111287101439, 2.6312915346739203, 1.7527484440637695], "isController": false}, {"data": ["https://www.demoblaze.com/index.html-7", 250, 3, 1.2, 258.15200000000004, 21, 609, 210.5, 413.0, 431.45, 515.4100000000001, 4.219195652540799, 112.84654099792415, 2.129062162464348], "isController": false}, {"data": ["https://www.demoblaze.com/index.html-9", 250, 2, 0.8, 265.6959999999998, 5, 666, 221.0, 419.9, 449.79999999999995, 565.1700000000012, 4.213293784549009, 142.5500802632466, 2.130610000674127], "isController": false}, {"data": ["https://www.demoblaze.com/prod.html?idp_=10-2", 250, 0, 0.0, 102.04400000000005, 50, 939, 62.0, 264.0, 278.45, 333.89000000000055, 4.282875351195778, 0.6901117509251011, 2.446759844188995], "isController": false}, {"data": ["https://api.demoblaze.com/addtocart", 250, 0, 0.0, 376.8839999999998, 281, 911, 347.5, 503.0, 539.8, 624.6200000000003, 4.307448439842175, 0.8288136533193198, 2.178963175623288], "isController": false}, {"data": ["https://www.demoblaze.com/prod.html?idp_=10-1", 250, 0, 0.0, 127.43199999999992, 50, 372, 65.5, 272.0, 281.45, 312.47, 4.268396790165614, 0.6902464465596722, 2.2800908634966706], "isController": false}, {"data": ["https://www.demoblaze.com/prod.html?idp_=10-0", 250, 0, 0.0, 124.61599999999993, 53, 1078, 75.0, 287.70000000000005, 303.34999999999997, 765.5800000000049, 4.260104968986436, 91.73408837481256, 2.196616624633631], "isController": false}, {"data": ["https://www.demoblaze.com/index.html-0", 250, 0, 0.0, 207.452, 142, 710, 187.5, 273.30000000000007, 371.45, 506.08000000000084, 4.175574559059326, 81.1550317761224, 2.1244866653026455], "isController": false}, {"data": ["https://www.demoblaze.com/index.html-2", 250, 0, 0.0, 262.28799999999995, 65, 1574, 237.0, 404.6, 457.0, 680.6600000000021, 4.214501255921374, 333.4104619988958, 2.3048053743320014], "isController": false}, {"data": ["Click on Home", 250, 0, 0.0, 978.0839999999993, 706, 1924, 945.5, 1254.0, 1334.9, 1725.6300000000008, 4.275038902854016, 18.232038958429523, 12.808417337847775], "isController": true}, {"data": ["https://www.demoblaze.com/index.html-1", 250, 0, 0.0, 197.66400000000016, 54, 696, 168.0, 366.9, 388.0, 463.2600000000007, 4.200904034548235, 23.354466506192132, 2.1414764707365026], "isController": false}, {"data": ["Load Website URL", 250, 5, 2.0, 1965.380000000001, 1412, 3251, 1908.5, 2371.4, 2503.45, 3039.29, 4.069739048332221, 5562.319961739366, 41.657467360692834], "isController": true}, {"data": ["https://www.demoblaze.com/prod.html?idp_=10-9", 250, 1, 0.4, 210.8680000000001, 63, 1003, 173.0, 359.9, 386.24999999999994, 573.5300000000018, 4.271605782045587, 4.642734906280969, 2.4924652878635136], "isController": false}, {"data": ["https://www.demoblaze.com/prod.html?idp_=10-8", 250, 4, 1.6, 289.53600000000006, 60, 500, 340.0, 400.9, 423.9, 459.47, 4.271167908152805, 6.2874928457937544, 2.3591528992687762], "isController": false}, {"data": ["Click on first result", 250, 5, 2.0, 1506.9520000000002, 992, 2653, 1467.5, 1849.0, 2027.6, 2425.6000000000004, 4.184520621317622, 146.50783119957651, 40.36226768064576], "isController": true}, {"data": ["https://www.demoblaze.com/prod.html?idp_=10-7", 250, 0, 0.0, 221.19600000000003, 116, 669, 174.5, 369.9, 406.9, 444.8800000000001, 4.265047086119831, 1.2914595897451209, 2.390342307347823], "isController": false}, {"data": ["https://www.demoblaze.com/prod.html?idp_=10-6", 250, 0, 0.0, 109.69600000000004, 50, 874, 64.0, 266.0, 277.45, 456.28000000000065, 4.283242243048298, 0.6926471186629432, 2.2671067341134545], "isController": false}, {"data": ["https://www.demoblaze.com/prod.html?idp_=10-5", 250, 0, 0.0, 102.54800000000007, 49, 858, 63.0, 264.9, 274.45, 363.430000000001, 4.283168859649123, 0.6951114587616501, 2.313078495494106], "isController": false}, {"data": ["https://www.demoblaze.com/prod.html?idp_=10-4", 250, 0, 0.0, 103.12399999999995, 48, 491, 61.0, 268.0, 285.34999999999997, 441.5600000000004, 4.267886713215084, 0.690163961537805, 2.3048255394608805], "isController": false}, {"data": ["https://api.demoblaze.com/login", 250, 0, 0.0, 370.9879999999999, 282, 639, 343.0, 483.5, 539.25, 595.4300000000001, 4.219765381044814, 1.038523820575576, 1.8708725419866656], "isController": false}, {"data": ["https://www.demoblaze.com/prod.html?idp_=10-3", 250, 0, 0.0, 109.68399999999998, 49, 847, 63.0, 268.0, 279.24999999999994, 646.4400000000032, 4.268688317453813, 0.6878257542772257, 2.41364310137281], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 4, 13.333333333333334, 0.024615384615384615], "isController": false}, {"data": ["Non HTTP response code: javax.net.ssl.SSLException/Non HTTP response message: Socket closed", 15, 50.0, 0.09230769230769231], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.impl.execchain.RequestAbortedException/Non HTTP response message: Request execution failed", 1, 3.3333333333333335, 0.006153846153846154], "isController": false}, {"data": ["Assertion failed", 10, 33.333333333333336, 0.06153846153846154], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 16250, 30, "Non HTTP response code: javax.net.ssl.SSLException/Non HTTP response message: Socket closed", 15, "Assertion failed", 10, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 4, "Non HTTP response code: org.apache.http.impl.execchain.RequestAbortedException/Non HTTP response message: Request execution failed", 1, null, null], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["https://www.demoblaze.com/index.html-11", 250, 2, "Non HTTP response code: javax.net.ssl.SSLException/Non HTTP response message: Socket closed", 2, null, null, null, null, null, null, null, null], "isController": false}, {"data": ["https://www.demoblaze.com/index.html-10", 250, 1, "Non HTTP response code: javax.net.ssl.SSLException/Non HTTP response message: Socket closed", 1, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["https://www.demoblaze.com/index.html-12", 250, 1, "Non HTTP response code: org.apache.http.impl.execchain.RequestAbortedException/Non HTTP response message: Request execution failed", 1, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["https://www.demoblaze.com/prod.html?idp_=10-11", 250, 1, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 1, null, null, null, null, null, null, null, null], "isController": false}, {"data": ["https://www.demoblaze.com/prod.html?idp_=10-10", 250, 1, "Non HTTP response code: javax.net.ssl.SSLException/Non HTTP response message: Socket closed", 1, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": ["https://www.demoblaze.com/prod.html?idp_=10-12", 250, 3, "Non HTTP response code: javax.net.ssl.SSLException/Non HTTP response message: Socket closed", 2, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 1, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": ["https://www.demoblaze.com/prod.html?idp_=10", 250, 5, "Assertion failed", 5, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["https://www.demoblaze.com/index.html", 1000, 5, "Assertion failed", 5, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": ["https://www.demoblaze.com/index.html-8", 250, 1, "Non HTTP response code: javax.net.ssl.SSLException/Non HTTP response message: Socket closed", 1, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": ["https://www.demoblaze.com/index.html-7", 250, 3, "Non HTTP response code: javax.net.ssl.SSLException/Non HTTP response message: Socket closed", 2, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 1, null, null, null, null, null, null], "isController": false}, {"data": ["https://www.demoblaze.com/index.html-9", 250, 2, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 1, "Non HTTP response code: javax.net.ssl.SSLException/Non HTTP response message: Socket closed", 1, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["https://www.demoblaze.com/prod.html?idp_=10-9", 250, 1, "Non HTTP response code: javax.net.ssl.SSLException/Non HTTP response message: Socket closed", 1, null, null, null, null, null, null, null, null], "isController": false}, {"data": ["https://www.demoblaze.com/prod.html?idp_=10-8", 250, 4, "Non HTTP response code: javax.net.ssl.SSLException/Non HTTP response message: Socket closed", 4, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
